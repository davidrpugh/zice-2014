class Variables:
  NEOS_HOST="www.neos-server.org"
  NEOS_PORT=3332
